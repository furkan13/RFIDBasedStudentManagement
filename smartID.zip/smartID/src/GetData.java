public class GetData {
    public static  String getuid;


    public static void setuid(String str)
    {
        getuid=str;
    }

    public  static  String getuid()
    {
        return  getuid;
    }


}
